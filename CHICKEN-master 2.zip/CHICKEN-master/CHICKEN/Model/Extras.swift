//
//  Extras.swift
//  CHICKEN
//
//  Created by Donald McAllister on 6/14/19.
//  Copyright © 2019 Donald McAllister. All rights reserved.
//

import Foundation

struct Extras {
    let id: String
    let imageName: String
    let calories: Int
    let price: Int
    let quantity: Int
}



